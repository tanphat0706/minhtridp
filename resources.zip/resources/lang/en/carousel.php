<?php
return [

    /*
     * |--------------------------------------------------------------------------
     * | Carousel Language Lines
     * |--------------------------------------------------------------------------
     * |
     */

    'add' => 'Add Slider',
    'title' => 'Title',
    'carousel'=>'Sliders',
    'description' => 'Description',
    'order_number' => 'Order number',
    'img_url' => 'Image',
    'created_at' => 'Created at',
    'del' => 'Del Slider',
    'edit' => 'Edit Slider',
    'list' => 'Sliders list',
    'name' => 'Name',
    'status' => 'Status',
    'created' => 'Create slider successful',
    'updated' => 'Updated slider successful',
    'deleted' => 'Deleted slider successful',
    'confirm_delete' => 'Do you want to delete this slider ?',
];
