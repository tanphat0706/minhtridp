<?php
return [

    /*
     * |--------------------------------------------------------------------------
     * | categorys Language Lines
     * |--------------------------------------------------------------------------
     * |
     */

    'add' => 'Add Category',
    'categories'=>'Categories',
    'description' => 'Description',
    'order_number' => 'Order number',
    'image_url' => 'Image',
    'created_at' => 'Created at',
    'del' => 'Del Category',
    'edit' => 'Edit Category',
    'list' => 'Categories list',
    'name' => 'Name',
    'status' => 'Status',
    'created' => 'Create category successful',
    'updated' => 'Updated category successful',
    'deleted' => 'Deleted category successful',
    'confirm_delete' => 'Do you want to delete this category ?',
    'flyer-leaflet' => 'Flyer & Leaflet',
];
