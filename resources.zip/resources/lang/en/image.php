<?php
return [

    /*
     * |--------------------------------------------------------------------------
     * | categorys Language Lines
     * |--------------------------------------------------------------------------
     * |
     */

    'add' => 'Add Image',
    'images'=>'Images',
    'del' => 'Del Image',
    'edit' => 'Edit Image',
    'list' => 'Images list',
    'name' => 'Name',
    'category_name' => 'Category Name',
    'status' => 'Status',
    'bought' => 'Bought',
    'price' => 'Price',
    'description' => 'Description',
    'image_url' => 'Browse your computer',
    'created_at' => 'Create At',
    'created' => 'Create image successful',
    'updated' => 'Updated image successful',
    'deleted' => 'Deleted image successful',
    'confirm_delete' => 'Do you want to delete this image ?',
    'currency' => 'VND'
];