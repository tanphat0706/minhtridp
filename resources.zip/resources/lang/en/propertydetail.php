<?php
return [

    /*
     * |--------------------------------------------------------------------------
     * | Property detail Language Lines
     * |--------------------------------------------------------------------------
     * |
     */
    'add' => 'Add Property detail',
    'title' => 'Title',
    'property'=>'Belong to Property',
    'description' => 'Description',
    'created_at' => 'Created at',
    'updated_at' => 'Updated at',
    'del' => 'Del Property detail',
    'edit' => 'Edit Property detail',
    'list' => 'Properties list',
    'name' => 'Name',
    'created' => 'Create Property detail successful',
    'updated' => 'Updated Property detail successful',
    'deleted' => 'Deleted Property detail successful',
    'confirm_delete' => 'Do you want to delete this Property detail ?',

];
