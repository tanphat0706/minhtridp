<footer class="main-footer">
    <!-- To the right -->
    <div class="pull-right hidden-xs">Version 1.0.</div>
    <!-- Default to the left -->
    <strong>© 2016 <a href="#" target="blank">{{ trans('system.app_name') }}</a>. All rights reserved
    </strong>
</footer>